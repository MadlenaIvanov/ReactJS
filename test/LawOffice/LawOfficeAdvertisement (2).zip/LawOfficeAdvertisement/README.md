# LawOfficeAdvertisement
Announcement of a law office.
