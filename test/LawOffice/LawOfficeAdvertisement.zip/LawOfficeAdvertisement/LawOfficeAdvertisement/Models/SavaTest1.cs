﻿namespace LawOfficeAdvertisement.Models
{
    public class SavaTest1
    {
    }
}
