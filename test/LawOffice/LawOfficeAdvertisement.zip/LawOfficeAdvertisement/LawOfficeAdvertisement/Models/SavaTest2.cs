﻿namespace LawOfficeAdvertisement.Models
{
    public class SavaTest2
    {
    }
}
