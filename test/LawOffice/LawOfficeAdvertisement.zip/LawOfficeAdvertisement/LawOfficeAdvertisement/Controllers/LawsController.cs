﻿using Microsoft.AspNetCore.Mvc;

namespace LawOfficeAdvertisement.Controllers
{
    public class LawsController : Controller
    {
        
    }
}
